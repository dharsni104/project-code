# Secure-LLM Pro: Real-Time AI Red-Team vs Blue-Team Simulator

A real-time, AI-driven cybersecurity training platform where an AI acts as a red-team attack orchestrator, while users serve as blue-team defenders.

## Features

- **Multi-Step Attack Simulation**: Reconnaissance → Brute-Force → SQL Injection → Data Exfiltration
- **Triple Risk Scoring**: Red-Team Risk, Blue-Team Defense, and LLM Analysis scores
- **AI-Powered Explanations**: Each attack step is explained by Llama3 via Ollama
- **Interactive Chat Assistant**: Ask cybersecurity questions in real-time
- **Tutorial Mode**: Step-by-step learning for beginners
- **PDF Export**: Download full session reports
- **Sidebar History**: Attack history, logs, risk evolution, user commands
- **Real-Time Dashboard**: Live-updating scores and visualizations

## Quick Start

### Prerequisites

1. **Python 3.10+** — [Download](https://python.org)
2. **Ollama** — [Download](https://ollama.com)

### Setup

```bash
# Install Ollama and pull Llama3
ollama serve
ollama pull llama3

# Install Python dependencies
pip install -r requirements.txt
```

### Run

**Option 1: Start script (Windows)**
```bash
start.bat
```

**Option 2: Manual start**
```bash
# Terminal 1: Victim App (Flask)
python victim/app.py

# Terminal 2: Backend API (FastAPI)
python -m uvicorn backend.main:app --host 0.0.0.0 --port 8000

# Terminal 3: Frontend
python -m http.server 3000 --directory frontend
```

### Access

| Service  | URL                     |
|----------|-------------------------|
| Frontend | http://localhost:3000    |
| Backend  | http://localhost:8000    |
| Victim   | http://localhost:5001    |
| Ollama   | http://localhost:11434   |

## Architecture

```
secure-llm-pro/
├── backend/
│   ├── main.py            # FastAPI server (port 8000)
│   ├── database.py        # SQLite database layer
│   ├── ollama_client.py   # LLM integration
│   └── pdf_export.py      # PDF report generation
├── victim/
│   └── app.py             # Flask vulnerable app (port 5001)
├── frontend/
│   ├── index.html         # Main UI
│   ├── style.css          # Premium dark theme
│   └── app.js             # Frontend logic
├── requirements.txt
├── start.bat              # Windows startup script
└── README.md
```

## API Endpoints

| Method | Endpoint          | Description                    |
|--------|-------------------|--------------------------------|
| GET    | /scenario         | Get current attack scenario    |
| POST   | /next_step        | Execute next attack step       |
| POST   | /chat             | Chat with AI assistant         |
| POST   | /risk_chat        | Risk-specific AI chat          |
| POST   | /tutorial         | Generate tutorial content      |
| GET    | /db/logs          | Get logs from database         |
| GET    | /db/commands      | Get command history            |
| GET    | /db/risk_events   | Get risk events                |
| GET    | /scores           | Get current risk scores        |
| POST   | /reset            | Reset entire session           |
| POST   | /export_pdf       | Export session as PDF           |

## Security Notice

This platform is for **educational purposes only**. All attacks are simulated against a local, intentionally vulnerable application. No real hacking instructions are generated.

## License

MIT
