"""
Ollama LLM client for Secure-LLM Pro.
Connects to local Ollama instance. Uses tinyllama (fits in low RAM).
Falls back to rule-based responses if Ollama is unavailable.
"""

import aiohttp
import asyncio
import json
import random

OLLAMA_URL = "http://localhost:11434/api/generate"
MODEL_NAME = "tinyllama"  # ~637MB on disk, needs ~1GB RAM (low-memory friendly)
TIMEOUT_SECONDS = 60
MAX_RETRIES = 1

# ─── Rule-based fallback responses ──────────────────────────────────────────
_FALLBACK_ATTACK = [
    ("SQL Injection exploits unsanitized user input to manipulate database queries. "
     "By injecting SQL syntax into form fields, attackers can bypass authentication or dump data. "
     "Defense: use parameterized queries and ORMs.\n\n"
     "The defense failed because input was not sanitized before being passed to the DB engine.\n\n"
     "Blue-team tip: Deploy a Web Application Firewall (WAF) and enforce input validation on all endpoints."),
    ("Cross-Site Scripting (XSS) injects malicious scripts into web pages viewed by other users. "
     "Stored XSS persists in the database; reflected XSS lives in a URL parameter. "
     "Defense: escape all output and use Content-Security-Policy headers.\n\n"
     "The defense succeeded because output encoding was applied before rendering.\n\n"
     "Blue-team tip: Add a strict CSP header and audit all user-controlled render paths."),
    ("Command Injection allows attackers to execute OS commands via vulnerable application inputs. "
     "When user input is passed to shell functions without sanitization, arbitrary commands run as the app user. "
     "Defense: never pass user input to shell commands; use safe APIs instead.\n\n"
     "The defense failed because shell=True was used with unsanitized input.\n\n"
     "Blue-team tip: Run the application as a low-privilege user and sandbox with AppArmor/SELinux."),
]

_FALLBACK_CHAT = [
    ("Great question! In cybersecurity, defense-in-depth means layering multiple controls "
     "so that if one fails, others still protect the system. Think of it like castle walls, a moat, and guards — "
     "each layer adds friction for the attacker."),
    ("SQL Injection is one of the most common web vulnerabilities. "
     "It works by inserting SQL code into an input field that gets executed by the database. "
     "Use parameterized queries or prepared statements to prevent it completely."),
    ("The Red Team simulates real-world attackers to find weaknesses before malicious actors do. "
     "The Blue Team defends by monitoring, patching, and responding to those simulated attacks. "
     "Together they strengthen overall security posture."),
    ("Zero-day vulnerabilities are flaws unknown to the vendor with no available patch. "
     "They are extremely valuable to attackers. Defense: network segmentation, anomaly detection, "
     "and keeping software up to date to minimize the attack surface."),
    ("Phishing is the #1 attack vector. Attackers craft convincing emails or pages to steal credentials. "
     "Train users to verify sender domains, hover over links before clicking, and report suspicious messages."),
]

_FALLBACK_TUTORIAL = (
    "## What is {topic}?\n"
    "{topic} is a well-known cybersecurity attack technique that exploits "
    "weaknesses in software or human behavior to gain unauthorized access or data.\n\n"
    "## Why does it work?\n"
    "It works because applications often trust user input without proper validation, "
    "or users can be socially engineered into taking unsafe actions.\n\n"
    "## How to defend against it?\n"
    "1. Validate and sanitize all user inputs\n"
    "2. Apply the principle of least privilege\n"
    "3. Keep all software patched and up to date\n\n"
    "## Real-world example (simulated)\n"
    "In this simulation, the red-team applies {topic} against the vulnerable victim app "
    "running on port 5001, while the blue-team monitors traffic and applies countermeasures in real time."
)


def _is_memory_error(text: str) -> bool:
    return "memory" in text.lower() or "requires more" in text.lower()


def _fallback_attack_explanation(step_name: str, success: bool) -> str:
    base = random.choice(_FALLBACK_ATTACK)
    status = "succeeded ✅" if success else "was blocked 🛡️"
    return f"**[Simulated AI Analysis — {step_name} {status}]**\n\n{base}"


def _fallback_chat(message: str) -> str:
    low = message.lower()
    for resp in _FALLBACK_CHAT:
        kw_map = {
            "sql": "SQL Injection",
            "xss": "XSS",
            "red team": "Red Team",
            "phish": "Phishing",
            "zero": "Zero-day",
        }
        for kw in kw_map:
            if kw in low:
                return next((r for r in _FALLBACK_CHAT if kw_map[kw] in r), random.choice(_FALLBACK_CHAT))
    return random.choice(_FALLBACK_CHAT)
# ─────────────────────────────────────────────────────────────────────────────


async def query_ollama(prompt: str, system_prompt: str = None, _fallback: str = None) -> str:
    """Send a prompt to Ollama. Falls back to rule-based response on ANY error."""
    payload = {
        "model": MODEL_NAME,
        "prompt": prompt,
        "stream": False,
        "options": {
            "temperature": 0.7,
            "num_predict": 256,
        },
    }
    if system_prompt:
        payload["system"] = system_prompt

    for attempt in range(MAX_RETRIES + 1):
        try:
            timeout = aiohttp.ClientTimeout(total=TIMEOUT_SECONDS)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.post(OLLAMA_URL, json=payload) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        return data.get("response", "No response from LLM.")
                    else:
                        error_text = await resp.text()
                        # On 404 (model not found/downloading) or 500 (memory) → fallback immediately
                        if resp.status in (404, 500) or _is_memory_error(error_text):
                            return _fallback or (
                                random.choice(_FALLBACK_CHAT)
                            )
                        if attempt < MAX_RETRIES:
                            await asyncio.sleep(1)
                            continue
                        # All other errors → also use fallback
                        return _fallback or random.choice(_FALLBACK_CHAT)
        except asyncio.TimeoutError:
            if attempt < MAX_RETRIES:
                await asyncio.sleep(1)
                continue
            return _fallback or "[LLM Timeout]: Ollama timed out. Is 'ollama serve' running?"
        except aiohttp.ClientError as e:
            if attempt < MAX_RETRIES:
                await asyncio.sleep(1)
                continue
            return _fallback or f"[LLM Connection Error]: Cannot reach Ollama. Error: {str(e)[:100]}"
        except Exception as e:
            return _fallback or f"[LLM Error]: {str(e)[:200]}"

    return _fallback or "[LLM Error]: All retry attempts failed."


async def explain_attack_step(step_name: str, step_details: str, success: bool) -> str:
    """Have the LLM explain an attack step for educational purposes."""
    system = (
        "You are a cybersecurity instructor explaining simulated attack techniques. "
        "Keep explanations concise (2-3 sentences), educational, and safe. "
        "Never provide actual exploit code or harmful instructions."
    )
    outcome = "succeeded" if success else "was blocked"
    prompt = (
        f"Explain this simulated cybersecurity attack step:\n"
        f"Step: {step_name}\nDetails: {step_details}\nOutcome: The attack {outcome}.\n\n"
        f"Provide:\n1. Brief explanation (2-3 sentences)\n"
        f"2. Why defense {'failed' if success else 'succeeded'} (1-2 sentences)\n"
        f"3. One blue-team improvement (1-2 sentences)"
    )
    fallback = _fallback_attack_explanation(step_name, success)
    return await query_ollama(prompt, system, _fallback=fallback)


async def chat_response(user_message: str, history: list = None) -> str:
    """Generate a chat response for the interactive assistant."""
    system = (
        "You are a cybersecurity training assistant called Secure-LLM Pro. "
        "Help users learn about cybersecurity concepts, attack techniques, and defense strategies. "
        "Keep answers educational, concise, and safe. Never provide actual exploit code."
    )
    context = ""
    if history:
        for msg in history[-6:]:
            context += f"{msg.get('role','user')}: {msg.get('content','')}\n"
    prompt = f"{context}user: {user_message}\nassistant:"
    fallback = _fallback_chat(user_message)
    return await query_ollama(prompt, system, _fallback=fallback)


async def generate_tutorial(topic: str) -> str:
    """Generate a tutorial explanation for a cybersecurity topic."""
    system = (
        "You are a cybersecurity instructor creating educational content. "
        "Explain concepts clearly for beginners. Never provide actual exploit code."
    )
    prompt = (
        f"Create a beginner-friendly tutorial about: {topic}\n\n"
        f"Structure: ## What is {topic}? / ## Why does it work? / "
        f"## How to defend against it? / ## Real-world example (simulated)"
    )
    fallback = _FALLBACK_TUTORIAL.format(topic=topic)
    return await query_ollama(prompt, system, _fallback=fallback)


async def score_llm_quality(explanation: str) -> float:
    """Self-evaluate the quality of an LLM explanation. Returns 0-100 score."""
    system = "You are an evaluator. Rate cybersecurity explanations. Return ONLY a number 0-100."
    prompt = (
        f"Rate this explanation on clarity, correctness, and usefulness (0-100):\n\n"
        f"{explanation}\n\nReturn ONLY the numeric score:"
    )
    result = await query_ollama(prompt, system, _fallback="72")
    try:
        score = float(result.strip().split()[0].replace(",", ""))
        return max(0, min(100, score))
    except (ValueError, IndexError):
        return 72.0

