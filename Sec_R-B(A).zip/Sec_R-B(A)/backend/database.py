"""
SQLite Database module for Secure-LLM Pro.
Manages logs, commands, risk_events, chat_history, and session_reports.
"""

import sqlite3
import os
import json
from datetime import datetime

DB_PATH = os.path.join(os.path.dirname(__file__), "..", "secure_llm_pro.db")


def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            source TEXT NOT NULL,
            level TEXT NOT NULL,
            message TEXT NOT NULL,
            step_index INTEGER,
            session_id TEXT
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS commands (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            user_input TEXT NOT NULL,
            response TEXT,
            session_id TEXT
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS risk_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            event_type TEXT NOT NULL,
            red_score REAL DEFAULT 0,
            blue_score REAL DEFAULT 0,
            llm_score REAL DEFAULT 0,
            description TEXT,
            step_index INTEGER,
            session_id TEXT
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS chat_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            role TEXT NOT NULL,
            content TEXT NOT NULL,
            session_id TEXT
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS session_reports (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            session_id TEXT NOT NULL,
            total_steps INTEGER,
            red_final REAL,
            blue_final REAL,
            llm_final REAL,
            summary TEXT,
            pdf_path TEXT
        )
    """)

    conn.commit()
    conn.close()


def insert_log(source, level, message, step_index=None, session_id=None):
    conn = get_connection()
    conn.execute(
        "INSERT INTO logs (timestamp, source, level, message, step_index, session_id) VALUES (?, ?, ?, ?, ?, ?)",
        (datetime.now().isoformat(), source, level, message, step_index, session_id),
    )
    conn.commit()
    conn.close()


def insert_command(user_input, response=None, session_id=None):
    conn = get_connection()
    conn.execute(
        "INSERT INTO commands (timestamp, user_input, response, session_id) VALUES (?, ?, ?, ?)",
        (datetime.now().isoformat(), user_input, response, session_id),
    )
    conn.commit()
    conn.close()


def insert_risk_event(event_type, red_score, blue_score, llm_score, description="", step_index=None, session_id=None):
    conn = get_connection()
    conn.execute(
        "INSERT INTO risk_events (timestamp, event_type, red_score, blue_score, llm_score, description, step_index, session_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        (datetime.now().isoformat(), event_type, red_score, blue_score, llm_score, description, step_index, session_id),
    )
    conn.commit()
    conn.close()


def insert_chat(role, content, session_id=None):
    conn = get_connection()
    conn.execute(
        "INSERT INTO chat_history (timestamp, role, content, session_id) VALUES (?, ?, ?, ?)",
        (datetime.now().isoformat(), role, content, session_id),
    )
    conn.commit()
    conn.close()


def insert_session_report(session_id, total_steps, red_final, blue_final, llm_final, summary, pdf_path=None):
    conn = get_connection()
    conn.execute(
        "INSERT INTO session_reports (timestamp, session_id, total_steps, red_final, blue_final, llm_final, summary, pdf_path) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        (datetime.now().isoformat(), session_id, total_steps, red_final, blue_final, llm_final, summary, pdf_path),
    )
    conn.commit()
    conn.close()


def get_logs(session_id=None, limit=100):
    conn = get_connection()
    if session_id:
        rows = conn.execute(
            "SELECT * FROM logs WHERE session_id = ? ORDER BY id DESC LIMIT ?",
            (session_id, limit),
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT * FROM logs ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_commands(session_id=None, limit=50):
    conn = get_connection()
    if session_id:
        rows = conn.execute(
            "SELECT * FROM commands WHERE session_id = ? ORDER BY id DESC LIMIT ?",
            (session_id, limit),
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT * FROM commands ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_risk_events(session_id=None, limit=100):
    conn = get_connection()
    if session_id:
        rows = conn.execute(
            "SELECT * FROM risk_events WHERE session_id = ? ORDER BY id ASC LIMIT ?",
            (session_id, limit),
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT * FROM risk_events ORDER BY id ASC LIMIT ?", (limit,)
        ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_chat_history(session_id=None, limit=50):
    conn = get_connection()
    if session_id:
        rows = conn.execute(
            "SELECT * FROM chat_history WHERE session_id = ? ORDER BY id ASC LIMIT ?",
            (session_id, limit),
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT * FROM chat_history ORDER BY id ASC LIMIT ?", (limit,)
        ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def clear_all(session_id=None):
    conn = get_connection()
    if session_id:
        for table in ["logs", "commands", "risk_events", "chat_history"]:
            conn.execute(f"DELETE FROM {table} WHERE session_id = ?", (session_id,))
    else:
        for table in ["logs", "commands", "risk_events", "chat_history"]:
            conn.execute(f"DELETE FROM {table}")
    conn.commit()
    conn.close()
