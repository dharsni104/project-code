"""
PDF Export module for Secure-LLM Pro.
Generates session reports as downloadable PDFs.
"""

import os
from datetime import datetime
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch, mm
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    HRFlowable, PageBreak
)
from reportlab.lib.enums import TA_CENTER, TA_LEFT

EXPORT_DIR = os.path.join(os.path.dirname(__file__), "..", "exports")


def ensure_export_dir():
    os.makedirs(EXPORT_DIR, exist_ok=True)


def generate_session_pdf(session_data: dict) -> str:
    """
    Generate a PDF report from session data.
    Returns the file path of the generated PDF.
    """
    ensure_export_dir()

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"session_report_{timestamp}.pdf"
    filepath = os.path.join(EXPORT_DIR, filename)

    doc = SimpleDocTemplate(
        filepath,
        pagesize=A4,
        rightMargin=30,
        leftMargin=30,
        topMargin=40,
        bottomMargin=40,
    )

    styles = getSampleStyleSheet()

    # Custom styles
    title_style = ParagraphStyle(
        "CustomTitle",
        parent=styles["Title"],
        fontSize=24,
        spaceAfter=6,
        textColor=colors.HexColor("#0ff"),
        fontName="Helvetica-Bold",
    )

    subtitle_style = ParagraphStyle(
        "CustomSubtitle",
        parent=styles["Normal"],
        fontSize=11,
        spaceAfter=20,
        textColor=colors.HexColor("#888888"),
        alignment=TA_CENTER,
    )

    heading_style = ParagraphStyle(
        "CustomHeading",
        parent=styles["Heading2"],
        fontSize=16,
        spaceBefore=20,
        spaceAfter=10,
        textColor=colors.HexColor("#00e5ff"),
        fontName="Helvetica-Bold",
    )

    body_style = ParagraphStyle(
        "CustomBody",
        parent=styles["Normal"],
        fontSize=10,
        spaceAfter=6,
        textColor=colors.HexColor("#333333"),
        leading=14,
    )

    elements = []

    # Title
    elements.append(Paragraph("Secure-LLM Pro", title_style))
    elements.append(Paragraph("AI Red-Team vs Blue-Team Simulation Report", subtitle_style))
    elements.append(Paragraph(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", subtitle_style))
    elements.append(HRFlowable(width="100%", thickness=2, color=colors.HexColor("#00e5ff")))
    elements.append(Spacer(1, 20))

    # Risk Scores Summary
    elements.append(Paragraph("Risk Scores Summary", heading_style))
    scores = session_data.get("scores", {})
    score_data = [
        ["Metric", "Score", "Rating"],
        ["Red-Team Risk Score", f"{scores.get('red', 0):.1f}", _get_rating(scores.get('red', 0))],
        ["Blue-Team Defense Score", f"{scores.get('blue', 0):.1f}", _get_rating(scores.get('blue', 0))],
        ["LLM Analysis Score", f"{scores.get('llm', 0):.1f}", _get_rating(scores.get('llm', 0))],
    ]
    score_table = Table(score_data, colWidths=[200, 100, 100])
    score_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1a1a2e")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("ALIGN", (0, 0), (-1, -1), "CENTER"),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, 0), 11),
        ("BOTTOMPADDING", (0, 0), (-1, 0), 12),
        ("BACKGROUND", (0, 1), (-1, -1), colors.HexColor("#f0f0f0")),
        ("GRID", (0, 0), (-1, -1), 1, colors.HexColor("#cccccc")),
        ("FONTSIZE", (0, 1), (-1, -1), 10),
        ("TOPPADDING", (0, 1), (-1, -1), 8),
        ("BOTTOMPADDING", (0, 1), (-1, -1), 8),
    ]))
    elements.append(score_table)
    elements.append(Spacer(1, 20))

    # Attack Steps
    steps = session_data.get("steps", [])
    if steps:
        elements.append(Paragraph("Attack Simulation Steps", heading_style))
        for i, step in enumerate(steps):
            step_name = step.get("name", f"Step {i+1}")
            status = "✓ Success" if step.get("success") else "✗ Blocked"
            elements.append(Paragraph(
                f"<b>Step {i+1}: {step_name}</b> — {status}",
                body_style,
            ))
            if step.get("description"):
                elements.append(Paragraph(f"  {step['description']}", body_style))
            if step.get("llm_explanation"):
                elements.append(Paragraph(
                    f"  <i>AI Analysis: {step['llm_explanation'][:300]}</i>",
                    body_style,
                ))
            elements.append(Spacer(1, 8))
        elements.append(Spacer(1, 10))

    # Logs
    logs = session_data.get("logs", [])
    if logs:
        elements.append(Paragraph("Session Logs", heading_style))
        log_data = [["Time", "Source", "Level", "Message"]]
        for log in logs[-30:]:  # Last 30 logs
            log_data.append([
                log.get("timestamp", "")[:19],
                log.get("source", ""),
                log.get("level", ""),
                log.get("message", "")[:60],
            ])
        log_table = Table(log_data, colWidths=[120, 70, 60, 270])
        log_table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1a1a2e")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE", (0, 0), (-1, -1), 8),
            ("ALIGN", (0, 0), (-1, -1), "LEFT"),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#dddddd")),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f8f8f8")]),
            ("TOPPADDING", (0, 0), (-1, -1), 4),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ]))
        elements.append(log_table)
        elements.append(Spacer(1, 20))

    # LLM Explanations
    explanations = session_data.get("explanations", [])
    if explanations:
        elements.append(Paragraph("AI Explanations", heading_style))
        for exp in explanations:
            elements.append(Paragraph(f"<b>{exp.get('title', 'Analysis')}:</b>", body_style))
            elements.append(Paragraph(exp.get("content", "")[:500], body_style))
            elements.append(Spacer(1, 6))

    # Footer
    elements.append(Spacer(1, 30))
    elements.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#cccccc")))
    elements.append(Paragraph(
        "This report was generated by Secure-LLM Pro — AI Red-Team vs Blue-Team Simulator. "
        "All attacks are simulated for educational purposes only.",
        ParagraphStyle("Footer", parent=styles["Normal"], fontSize=8, textColor=colors.gray, alignment=TA_CENTER),
    ))

    doc.build(elements)
    return filepath


def _get_rating(score: float) -> str:
    if score >= 80:
        return "Excellent"
    elif score >= 60:
        return "Good"
    elif score >= 40:
        return "Moderate"
    elif score >= 20:
        return "Low"
    else:
        return "Minimal"
