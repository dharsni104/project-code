@echo off
title Secure-LLM Pro — Startup
echo.
echo  ========================================================
echo    Secure-LLM Pro: AI Red-Team vs Blue-Team Simulator
echo  ========================================================
echo.

:: Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python is not installed or not in PATH.
    echo Please install Python 3.10+ from https://python.org
    pause
    exit /b 1
)

:: Install dependencies
echo [1/4] Installing Python dependencies...
pip install -r requirements.txt --quiet
echo       Done.
echo.

:: Start Victim App (Flask) in background
echo [2/4] Starting Victim App on port 5001...
start /b cmd /c "python victim\app.py"
timeout /t 2 /nobreak >nul
echo       Done.
echo.

:: Start Backend (FastAPI) in background
echo [3/4] Starting Backend API on port 8000...
start /b cmd /c "python -m uvicorn backend.main:app --host 0.0.0.0 --port 8000 --reload"
timeout /t 3 /nobreak >nul
echo       Done.
echo.

:: Start Frontend (simple HTTP server)
echo [4/4] Starting Frontend on port 3000...
start /b cmd /c "python -m http.server 3000 --directory frontend"
timeout /t 2 /nobreak >nul
echo       Done.
echo.

echo  ========================================================
echo    All services started!
echo.
echo    Frontend:   http://localhost:3000
echo    Backend:    http://localhost:8000
echo    Victim:     http://localhost:5001
echo.
echo    IMPORTANT: Make sure Ollama is running:
echo      ollama serve
echo      ollama pull llama3
echo  ========================================================
echo.
echo  Press any key to open the app in your browser...
pause >nul
start http://localhost:3000
echo.
echo  Press Ctrl+C or close this window to stop all services.
pause >nul
