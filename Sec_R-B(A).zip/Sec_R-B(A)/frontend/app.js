/**
 * Secure-LLM Pro — Frontend Application
 * Handles all UI interactions, API calls, and real-time updates.
 */

const API_BASE = "http://localhost:8001";
const POLL_INTERVAL = 5000;

// ─── State ──────────────────────────────────────────────
const state = {
    sessionId: null,
    scenario: null,
    currentStep: -1,
    totalSteps: 4,
    scores: { red: 0, blue: 0, llm: 0 },
    isRunning: false,
    logs: [],
    chatHistory: [],
    pollTimer: null,
};

// ─── DOM Elements ───────────────────────────────────────
const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => document.querySelectorAll(sel);

const els = {
    sessionId: $("#session-id"),
    redScore: $("#red-score"),
    blueScore: $("#blue-score"),
    llmScore: $("#llm-score"),
    redBar: $("#red-bar"),
    blueBar: $("#blue-bar"),
    llmBar: $("#llm-bar"),
    progressText: $("#progress-text"),
    progressBar: $("#progress-bar"),
    redContent: $("#red-content"),
    blueContent: $("#blue-content"),
    llmContent: $("#llm-content"),
    chatMessages: $("#chat-messages"),
    chatInput: $("#chat-input"),
    btnNextStep: $("#btn-next-step"),
    btnReset: $("#btn-reset"),
    btnExport: $("#btn-export"),
    btnSendChat: $("#btn-send-chat"),
    btnTutorial: $("#btn-tutorial"),
    tutorialModal: $("#tutorial-modal"),
    closeTutorial: $("#close-tutorial"),
    tutorialContent: $("#tutorial-content"),
    toastContainer: $("#toast-container"),
    logFilterSelect: $("#log-filter-select"),
    statusBackend: $("#status-backend"),
    statusVictim: $("#status-victim"),
    statusLlm: $("#status-llm"),
    sidebarToggle: $("#sidebar-toggle"),
    sidebar: $("#sidebar"),
    attacksList: $("#attacks-list"),
    logsList: $("#logs-list"),
    risksList: $("#risks-list"),
    commandsList: $("#commands-list"),
    attacksEmpty: $("#attacks-empty"),
};

// ─── Initialization ─────────────────────────────────────
document.addEventListener("DOMContentLoaded", () => {
    initEventListeners();
    loadScenario();
    checkServices();
    startPolling();
});

function initEventListeners() {
    els.btnNextStep.addEventListener("click", executeNextStep);
    els.btnReset.addEventListener("click", resetSession);
    els.btnExport.addEventListener("click", exportPDF);
    els.btnSendChat.addEventListener("click", sendChat);
    els.btnTutorial.addEventListener("click", () => els.tutorialModal.classList.add("active"));
    els.closeTutorial.addEventListener("click", () => els.tutorialModal.classList.remove("active"));

    els.chatInput.addEventListener("keydown", (e) => {
        if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            sendChat();
        }
    });

    els.tutorialModal.addEventListener("click", (e) => {
        if (e.target === els.tutorialModal) els.tutorialModal.classList.remove("active");
    });

    // Tutorial topic buttons
    $$(".topic-btn").forEach((btn) => {
        btn.addEventListener("click", () => {
            $$(".topic-btn").forEach((b) => b.classList.remove("active"));
            btn.classList.add("active");
            loadTutorial(btn.dataset.topic);
        });
    });

    // Sidebar tabs
    $$(".sidebar-tab").forEach((tab) => {
        tab.addEventListener("click", () => {
            $$(".sidebar-tab").forEach((t) => t.classList.remove("active"));
            tab.classList.add("active");
            $$(".sidebar-panel").forEach((p) => p.classList.remove("active"));
            $(`#panel-${tab.dataset.tab}`).classList.add("active");
        });
    });

    // Sidebar toggle
    els.sidebarToggle.addEventListener("click", () => {
        els.sidebar.classList.toggle("collapsed");
        els.sidebar.classList.toggle("open");
    });

    // Log filter
    els.logFilterSelect.addEventListener("change", () => {
        renderLogs();
    });
}

// ─── API Helpers ────────────────────────────────────────
async function api(endpoint, options = {}) {
    try {
        const url = `${API_BASE}${endpoint}`;
        const config = {
            headers: { "Content-Type": "application/json" },
            ...options,
        };
        const response = await fetch(url, config);
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        return await response.json();
    } catch (error) {
        console.error(`API error [${endpoint}]:`, error);
        throw error;
    }
}

// ─── Service Health Checks ──────────────────────────────
async function checkServices() {
    // Backend
    try {
        await api("/");
        els.statusBackend.classList.add("online");
        els.statusBackend.classList.remove("offline");
    } catch {
        els.statusBackend.classList.add("offline");
        els.statusBackend.classList.remove("online");
    }

    // Victim
    try {
        const r = await fetch("http://localhost:5001/", { mode: "cors" });
        if (r.ok) {
            els.statusVictim.classList.add("online");
            els.statusVictim.classList.remove("offline");
        } else throw new Error();
    } catch {
        els.statusVictim.classList.add("offline");
        els.statusVictim.classList.remove("online");
    }

    // Ollama — check via backend (avoids CORS)
    try {
        const data = await api("/scenario");
        // If backend responds, mark LLM as potentially available
        els.statusLlm.classList.add("online");
        els.statusLlm.classList.remove("offline");
    } catch {
        els.statusLlm.classList.add("offline");
        els.statusLlm.classList.remove("online");
    }
}

// ─── Load Scenario ──────────────────────────────────────
async function loadScenario() {
    try {
        const data = await api("/scenario");
        state.scenario = data.scenario;
        state.sessionId = data.session_id;
        state.currentStep = data.current_step;
        state.totalSteps = data.total_steps;
        state.scores = data.scores;

        els.sessionId.textContent = state.sessionId;
        updateScores(state.scores);
        renderScenarioOverview();
        updateProgress();

        // Restore completed steps
        if (data.steps_completed && data.steps_completed.length > 0) {
            data.steps_completed.forEach((step) => {
                addLLMExplanation(step.name, step.llm_explanation || "No explanation available.");
            });
        }
    } catch (error) {
        els.redContent.innerHTML = `
            <div class="empty-state">
                <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="var(--red)" stroke-width="1.5">
                    <circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/>
                    <line x1="9" y1="9" x2="15" y2="15"/>
                </svg>
                <p>Backend Unavailable</p>
                <span>Make sure the FastAPI server is running on port 8000</span>
            </div>
        `;
        showToast("Cannot connect to backend. Start the server first.", "error");
    }
}

// ─── Render Scenario Overview ───────────────────────────
function renderScenarioOverview() {
    if (!state.scenario) return;

    const s = state.scenario;
    let stepsHTML = s.steps
        .map((step, i) => {
            let statusClass = "pending";
            let statusText = "Pending";

            if (i < state.currentStep + 1) {
                // Find the completed step data
                statusClass = "success"; // default
                statusText = "Executed";
            } else if (i === state.currentStep + 1) {
                statusClass = "pending";
                statusText = "Next";
            }

            return `
                <div class="step-item ${statusClass}" data-step="${i}">
                    <div class="step-number">${i + 1}</div>
                    <div class="step-info">
                        <div class="step-name">${step.name}</div>
                        <div class="step-type">${step.attack_type}</div>
                    </div>
                    <span class="step-status ${statusClass}">${statusText}</span>
                </div>
            `;
        })
        .join("");

    els.redContent.innerHTML = `
        <div class="scenario-info">
            <h3>${s.name}</h3>
            <span class="scenario-badge">${s.difficulty}</span>
            <p>${s.description}</p>
            <div class="step-list">${stepsHTML}</div>
        </div>
    `;
}

// ─── Execute Next Attack Step ───────────────────────────
async function executeNextStep() {
    if (state.isRunning) return;

    state.isRunning = true;
    els.btnNextStep.disabled = true;
    els.btnNextStep.innerHTML = `
        <div class="spinner" style="width:14px;height:14px;border-width:2px;"></div>
        Executing...
    `;

    // Mark the current step as active
    const nextIdx = state.currentStep + 1;
    const stepEl = $(`.step-item[data-step="${nextIdx}"]`);
    if (stepEl) {
        stepEl.className = "step-item active";
        stepEl.querySelector(".step-status").className = "step-status running";
        stepEl.querySelector(".step-status").textContent = "Running";
    }

    try {
        const data = await api("/next_step", { method: "POST" });

        if (data.complete && !data.step) {
            showToast("All attack steps have been completed!", "info");
            els.btnNextStep.disabled = true;
            els.btnNextStep.innerHTML = `✓ Simulation Complete`;
            state.isRunning = false;
            return;
        }

        state.currentStep = data.step_index;
        state.scores = data.scores;

        // Update step UI
        if (stepEl) {
            const success = data.success;
            stepEl.className = `step-item ${success ? "success" : "blocked"}`;
            const statusEl = stepEl.querySelector(".step-status");
            statusEl.className = `step-status ${success ? "success" : "blocked"}`;
            statusEl.textContent = success ? "✓ Success" : "✗ Blocked";
        }

        // Update scores
        updateScores(data.scores);
        updateProgress();

        // Add log entries
        addLogEntry("RED-TEAM", data.success ? "CRITICAL" : "INFO",
            `${data.step.name}: ${data.result.detail || (data.success ? "Attack succeeded" : "Attack blocked")}`);
        addLogEntry(data.success ? "RED-TEAM" : "BLUE-TEAM",
            data.success ? "WARNING" : "INFO",
            data.success ? `Defense failed for ${data.step.name}` : `Successfully blocked ${data.step.name}`);

        // Add LLM explanation
        if (data.llm_explanation) {
            addLLMExplanation(data.step.name, data.llm_explanation);
        }

        // Add to sidebar attack history
        addAttackHistoryItem(data);

        // Show toast
        if (data.success) {
            showToast(`⚠️ ${data.step.name} — Attack succeeded!`, "warning");
        } else {
            showToast(`🛡️ ${data.step.name} — Attack blocked!`, "success");
        }

        // Check if simulation is complete
        if (data.remaining === 0) {
            showToast("🏁 Simulation complete! Export your report.", "info");
            els.btnNextStep.innerHTML = `✓ Simulation Complete`;
            els.btnNextStep.disabled = true;
        }

        // Refresh sidebar data
        refreshSidebarData();

    } catch (error) {
        showToast("Failed to execute attack step. Check backend connection.", "error");
        if (stepEl) {
            stepEl.className = "step-item pending";
            stepEl.querySelector(".step-status").className = "step-status pending";
            stepEl.querySelector(".step-status").textContent = "Error";
        }
    } finally {
        state.isRunning = false;
        if (!els.btnNextStep.disabled || els.btnNextStep.textContent.includes("Complete")) {
            // Keep disabled if complete
        } else {
            els.btnNextStep.disabled = false;
            els.btnNextStep.innerHTML = `
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polygon points="5 3 19 12 5 21 5 3"/>
                </svg>
                Execute Next Attack
            `;
        }
    }
}

// ─── Score Updates ──────────────────────────────────────
function updateScores(scores) {
    if (!scores) return;

    animateValue(els.redScore, parseFloat(els.redScore.textContent) || 0, scores.red, 600);
    animateValue(els.blueScore, parseFloat(els.blueScore.textContent) || 0, scores.blue, 600);
    animateValue(els.llmScore, parseFloat(els.llmScore.textContent) || 0, scores.llm, 600);

    els.redBar.style.width = `${scores.red}%`;
    els.blueBar.style.width = `${scores.blue}%`;
    els.llmBar.style.width = `${scores.llm}%`;

    state.scores = scores;
}

function updateProgress() {
    const completed = state.currentStep + 1;
    els.progressText.textContent = `${completed} / ${state.totalSteps}`;
    els.progressBar.style.width = `${(completed / state.totalSteps) * 100}%`;
}

function animateValue(el, start, end, duration) {
    const range = end - start;
    const startTime = performance.now();

    function step(currentTime) {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1);
        const eased = 1 - Math.pow(1 - progress, 3); // ease-out cubic
        const current = start + range * eased;
        el.textContent = current.toFixed(1);
        if (progress < 1) requestAnimationFrame(step);
    }

    requestAnimationFrame(step);
}

// ─── Log Rendering ──────────────────────────────────────
function addLogEntry(source, level, message) {
    const timestamp = new Date().toLocaleTimeString("en-US", { hour12: false });
    const logEntry = { timestamp, source, level, message };
    state.logs.push(logEntry);
    renderLogs();
}

function renderLogs() {
    const filter = els.logFilterSelect.value;
    const filteredLogs = filter === "all"
        ? state.logs
        : state.logs.filter((l) => l.source === filter);

    if (filteredLogs.length === 0) {
        els.blueContent.innerHTML = `
            <div class="empty-state">
                <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" opacity="0.4">
                    <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
                    <line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="21" x2="9" y2="9"/>
                </svg>
                <p>Monitoring Active</p>
                <span>Logs will appear here during simulation</span>
            </div>
        `;
        return;
    }

    els.blueContent.innerHTML = filteredLogs
        .slice(-50)
        .reverse()
        .map((log) => `
            <div class="log-entry">
                <span class="log-time">${log.timestamp}</span>
                <span class="log-source ${log.source}">${log.source}</span>
                <span class="log-level ${log.level}">${log.level}</span>
                <span class="log-message">${escapeHtml(log.message)}</span>
            </div>
        `)
        .join("");

    // Auto-scroll to top (newest)
    els.blueContent.scrollTop = 0;
}

// ─── LLM Explanations ──────────────────────────────────
function addLLMExplanation(stepName, explanation) {
    const existing = els.llmContent.querySelector(".empty-state");
    if (existing) existing.remove();

    const div = document.createElement("div");
    div.className = "llm-explanation";
    div.innerHTML = `
        <h4>
            <span class="step-badge">${stepName}</span>
            AI Analysis
        </h4>
        <p>${escapeHtml(explanation)}</p>
    `;
    els.llmContent.prepend(div);
}

// ─── Chat ───────────────────────────────────────────────
async function sendChat() {
    const message = els.chatInput.value.trim();
    if (!message) return;

    els.chatInput.value = "";

    // Add user message
    appendChatMessage("user", message);

    // Show typing indicator
    const typingDiv = document.createElement("div");
    typingDiv.className = "chat-message assistant";
    typingDiv.id = "typing-indicator";
    typingDiv.innerHTML = `
        <div class="chat-avatar">AI</div>
        <div class="chat-bubble">
            <div class="typing-indicator">
                <span></span><span></span><span></span>
            </div>
        </div>
    `;
    els.chatMessages.appendChild(typingDiv);
    els.chatMessages.scrollTop = els.chatMessages.scrollHeight;

    try {
        const data = await api("/chat", {
            method: "POST",
            body: JSON.stringify({ message, session_id: state.sessionId }),
        });

        // Remove typing indicator
        const indicator = $("#typing-indicator");
        if (indicator) indicator.remove();

        appendChatMessage("assistant", data.response);
    } catch (error) {
        const indicator = $("#typing-indicator");
        if (indicator) indicator.remove();
        appendChatMessage("assistant", "Sorry, I couldn't process your request. Please ensure the backend and Ollama are running.");
    }
}

function appendChatMessage(role, content) {
    const div = document.createElement("div");
    div.className = `chat-message ${role}`;
    div.innerHTML = `
        <div class="chat-avatar">${role === "assistant" ? "AI" : "You"}</div>
        <div class="chat-bubble">
            <p>${formatMessage(content)}</p>
        </div>
    `;
    els.chatMessages.appendChild(div);
    els.chatMessages.scrollTop = els.chatMessages.scrollHeight;
    state.chatHistory.push({ role, content });
}

function formatMessage(text) {
    // Basic markdown-like formatting
    return escapeHtml(text)
        .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
        .replace(/\*(.*?)\*/g, "<em>$1</em>")
        .replace(/`(.*?)`/g, '<code style="background:rgba(0,240,255,0.1);padding:1px 4px;border-radius:3px;font-family:JetBrains Mono,monospace;font-size:0.78rem;">$1</code>')
        .replace(/\n/g, "<br>");
}

// ─── Tutorial Mode ──────────────────────────────────────
async function loadTutorial(topic) {
    els.tutorialContent.innerHTML = `
        <div class="loading-spinner">
            <div class="spinner"></div>
            <p>Generating tutorial for "${topic}"...</p>
        </div>
    `;

    try {
        const data = await api("/tutorial", {
            method: "POST",
            body: JSON.stringify({ topic }),
        });

        els.tutorialContent.innerHTML = `
            <div style="white-space: pre-wrap; line-height: 1.7;">
                ${formatTutorialContent(data.content)}
            </div>
        `;
    } catch (error) {
        els.tutorialContent.innerHTML = `
            <div class="empty-state">
                <p>Failed to load tutorial</p>
                <span>Ensure backend and Ollama are running</span>
            </div>
        `;
    }
}

function formatTutorialContent(content) {
    return escapeHtml(content)
        .replace(/## (.*?)(\n|$)/g, '<h3 style="color:var(--cyan);margin-top:16px;margin-bottom:8px;">$1</h3>')
        .replace(/# (.*?)(\n|$)/g, '<h2 style="color:var(--cyan);margin-top:20px;margin-bottom:10px;">$1</h2>')
        .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
        .replace(/\*(.*?)\*/g, "<em>$1</em>")
        .replace(/- (.*?)(\n|$)/g, '<li style="margin-left:20px;margin-bottom:4px;">$1</li>')
        .replace(/\n/g, "<br>");
}

// ─── Reset Session ──────────────────────────────────────
async function resetSession() {
    if (!confirm("Reset the entire session? All progress will be lost.")) return;

    try {
        const data = await api("/reset", { method: "POST" });

        state.currentStep = -1;
        state.scores = { red: 0, blue: 0, llm: 0 };
        state.logs = [];
        state.chatHistory = [];

        updateScores(state.scores);
        updateProgress();

        // Reload scenario
        await loadScenario();

        // Clear panels
        els.llmContent.innerHTML = `
            <div class="empty-state">
                <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" opacity="0.4">
                    <circle cx="12" cy="12" r="10"/>
                    <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/>
                    <line x1="12" y1="17" x2="12.01" y2="17"/>
                </svg>
                <p>AI Analysis Ready</p>
                <span>Run attack steps to see AI-powered explanations</span>
            </div>
        `;

        renderLogs();

        // Reset chat
        els.chatMessages.innerHTML = `
            <div class="chat-message assistant">
                <div class="chat-avatar">AI</div>
                <div class="chat-bubble">
                    <p>Session reset! Ready for a new simulation.</p>
                </div>
            </div>
        `;

        // Reset sidebar
        els.attacksList.innerHTML = "";
        els.logsList.innerHTML = "";
        els.risksList.innerHTML = "";
        els.commandsList.innerHTML = "";
        if (els.attacksEmpty) els.attacksEmpty.style.display = "flex";

        // Re-enable attack button
        els.btnNextStep.disabled = false;
        els.btnNextStep.innerHTML = `
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polygon points="5 3 19 12 5 21 5 3"/>
            </svg>
            Execute Next Attack
        `;

        showToast("Session reset successfully!", "success");
    } catch (error) {
        showToast("Failed to reset session.", "error");
    }
}

// ─── Export PDF ─────────────────────────────────────────
async function exportPDF() {
    els.btnExport.disabled = true;
    els.btnExport.innerHTML = `
        <div class="spinner" style="width:14px;height:14px;border-width:2px;"></div>
        Generating...
    `;

    try {
        const response = await fetch(`${API_BASE}/export_pdf`, { method: "POST" });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);

        const blob = await response.blob();
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `secure-llm-pro-report-${Date.now()}.pdf`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);

        showToast("PDF report downloaded!", "success");
    } catch (error) {
        showToast("Failed to export PDF. Run some steps first.", "error");
    } finally {
        els.btnExport.disabled = false;
        els.btnExport.innerHTML = `
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                <polyline points="14 2 14 8 20 8"/>
                <line x1="16" y1="13" x2="8" y2="13"/>
                <line x1="16" y1="17" x2="8" y2="17"/>
                <polyline points="10 9 9 9 8 9"/>
            </svg>
            Export PDF
        `;
    }
}

// ─── Sidebar Data ───────────────────────────────────────
function addAttackHistoryItem(data) {
    if (els.attacksEmpty) els.attacksEmpty.style.display = "none";

    const item = document.createElement("div");
    item.className = "history-item";
    item.innerHTML = `
        <div class="item-source ${data.success ? 'red' : 'blue'}">
            ${data.success ? "⚠️" : "🛡️"} ${data.step.name}
        </div>
        <div class="item-message">
            ${data.success ? "Attack succeeded" : "Attack blocked"} — 
            Red: ${data.scores.red} | Blue: ${data.scores.blue}
        </div>
        <div class="item-time">${new Date().toLocaleTimeString()}</div>
    `;
    els.attacksList.prepend(item);
}

async function refreshSidebarData() {
    try {
        // Logs
        const logsData = await api("/db/logs");
        els.logsList.innerHTML = (logsData.logs || [])
            .slice(0, 30)
            .map((log) => `
                <div class="history-item">
                    <div class="item-source ${log.source.toLowerCase().replace('-', '')}">${log.source}</div>
                    <div class="item-message">${escapeHtml(log.message).substring(0, 100)}</div>
                    <div class="item-time">${log.timestamp ? log.timestamp.substring(11, 19) : ""}</div>
                </div>
            `)
            .join("");

        // Risk events
        const riskData = await api("/db/risk_events");
        els.risksList.innerHTML = (riskData.risk_events || [])
            .map((ev) => `
                <div class="history-item">
                    <div class="item-source llm">${ev.event_type}</div>
                    <div class="item-message">
                        R: ${ev.red_score} | B: ${ev.blue_score} | L: ${ev.llm_score}
                        <br>${escapeHtml(ev.description || "")}
                    </div>
                    <div class="item-time">${ev.timestamp ? ev.timestamp.substring(11, 19) : ""}</div>
                </div>
            `)
            .join("");

        // Commands
        const cmdData = await api("/db/commands");
        els.commandsList.innerHTML = (cmdData.commands || [])
            .slice(0, 20)
            .map((cmd) => `
                <div class="history-item">
                    <div class="item-source system">User</div>
                    <div class="item-message">${escapeHtml(cmd.user_input || "").substring(0, 80)}</div>
                    <div class="item-time">${cmd.timestamp ? cmd.timestamp.substring(11, 19) : ""}</div>
                </div>
            `)
            .join("");
    } catch (error) {
        // Silently fail for polling
    }
}

// ─── Polling ────────────────────────────────────────────
function startPolling() {
    state.pollTimer = setInterval(() => {
        checkServices();
    }, POLL_INTERVAL);
}

// ─── Toast Notifications ────────────────────────────────
function showToast(message, type = "info") {
    const icons = {
        success: "✅",
        error: "❌",
        warning: "⚠️",
        info: "ℹ️",
    };

    const toast = document.createElement("div");
    toast.className = `toast ${type}`;
    toast.innerHTML = `
        <span class="toast-icon">${icons[type]}</span>
        <span>${escapeHtml(message)}</span>
    `;
    els.toastContainer.appendChild(toast);

    setTimeout(() => {
        toast.classList.add("removing");
        setTimeout(() => toast.remove(), 300);
    }, 4000);
}

// ─── Utilities ──────────────────────────────────────────
function escapeHtml(text) {
    if (!text) return "";
    const div = document.createElement("div");
    div.textContent = text;
    return div.innerHTML;
}
