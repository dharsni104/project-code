"""
Vulnerable Victim Application (Flask) for Secure-LLM Pro.
This app intentionally contains security vulnerabilities for training purposes.
Runs on port 5001.
"""

import sqlite3
import os
from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

VICTIM_DB = os.path.join(os.path.dirname(__file__), "victim.db")

# Simulated secret token
SECRET_TOKEN = "admin-secret-token-2024"

# Simulated users
USERS = {
    "admin": "admin123",
    "user1": "password1",
    "root": "toor",
}

# Track login attempts for brute-force detection
login_attempts = {}
MAX_ATTEMPTS = 5


def init_victim_db():
    """Initialize the victim database with intentionally vulnerable schema."""
    conn = sqlite3.connect(VICTIM_DB)
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            description TEXT,
            price REAL,
            category TEXT
        )
    """)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS secret_data (
            id INTEGER PRIMARY KEY,
            key TEXT NOT NULL,
            value TEXT NOT NULL
        )
    """)
    # Insert sample data
    cursor.execute("DELETE FROM products")
    cursor.execute("DELETE FROM secret_data")
    products = [
        (1, "Firewall Pro", "Enterprise firewall solution", 999.99, "security"),
        (2, "VPN Shield", "Military-grade VPN service", 49.99, "networking"),
        (3, "Antivirus Plus", "Real-time threat protection", 79.99, "security"),
        (4, "Password Manager", "Secure credential storage", 29.99, "tools"),
        (5, "Network Monitor", "Traffic analysis tool", 199.99, "monitoring"),
    ]
    cursor.executemany("INSERT INTO products VALUES (?, ?, ?, ?, ?)", products)
    secrets = [
        (1, "API_KEY", "sk-fake-demo-key-12345"),
        (2, "DB_PASSWORD", "demo_db_pass_67890"),
        (3, "ADMIN_EMAIL", "admin@demo-secure-llm.local"),
        (4, "ENCRYPTION_KEY", "demo-aes-256-key-not-real"),
    ]
    cursor.executemany("INSERT INTO secret_data VALUES (?, ?, ?)", secrets)
    conn.commit()
    conn.close()


@app.route("/", methods=["GET"])
def index():
    return jsonify({
        "app": "Vulnerable Demo App",
        "version": "1.0.0",
        "status": "running",
        "endpoints": ["/login", "/search", "/config", "/reset"],
        "note": "This is an intentionally vulnerable app for cybersecurity training."
    })


@app.route("/login", methods=["POST"])
def login():
    """
    Vulnerable login endpoint.
    - Accepts JSON or form data
    - Vulnerable to brute-force (limited protection)
    - Returns verbose error messages (information disclosure)
    """
    data = request.get_json(silent=True) or {}
    username = data.get("username", "")
    password = data.get("password", "")

    if not username or not password:
        return jsonify({
            "success": False,
            "error": "Missing credentials",
            "hint": "Both username and password are required"
        }), 400

    # Track attempts (weak brute-force protection)
    ip = request.remote_addr
    key = f"{ip}:{username}"
    login_attempts[key] = login_attempts.get(key, 0) + 1

    if login_attempts[key] > MAX_ATTEMPTS:
        return jsonify({
            "success": False,
            "error": "Too many attempts",
            "blocked": True,
            "attempts": login_attempts[key],
            "message": f"Account '{username}' temporarily locked after {MAX_ATTEMPTS} failed attempts"
        }), 429

    # Intentionally verbose: reveals if username exists
    if username not in USERS:
        return jsonify({
            "success": False,
            "error": "User not found",
            "message": f"No account found for username '{username}'",
            "hint": "Try: admin, user1, or root"
        }), 401

    if USERS[username] != password:
        return jsonify({
            "success": False,
            "error": "Invalid password",
            "message": f"Password incorrect for user '{username}'",
            "attempts_remaining": MAX_ATTEMPTS - login_attempts[key]
        }), 401

    # Successful login
    login_attempts[key] = 0
    return jsonify({
        "success": True,
        "message": f"Welcome back, {username}!",
        "token": SECRET_TOKEN if username == "admin" else "user-basic-token",
        "role": "administrator" if username == "admin" else "user",
    })


@app.route("/search", methods=["GET"])
def search():
    """
    Intentionally SQL-injectable search endpoint.
    The query parameter is directly interpolated into SQL (DO NOT do this in production!).
    """
    query = request.args.get("q", "")

    if not query:
        return jsonify({
            "success": False,
            "error": "Missing search query",
            "hint": "Use ?q=your_search_term"
        }), 400

    conn = sqlite3.connect(VICTIM_DB)
    conn.row_factory = sqlite3.Row
    try:
        # INTENTIONALLY VULNERABLE: Direct string interpolation in SQL
        sql = f"SELECT * FROM products WHERE name LIKE '%{query}%' OR category LIKE '%{query}%'"
        results = conn.execute(sql).fetchall()
        items = [dict(r) for r in results]

        # Check if injection was detected (educational)
        injection_detected = any(c in query.lower() for c in ["'", '"', ";", "--", "union", "select", "drop", "delete"])

        return jsonify({
            "success": True,
            "query": query,
            "sql_executed": sql,  # Intentionally exposing SQL (vulnerability)
            "results": items,
            "count": len(items),
            "injection_detected": injection_detected,
        })
    except sqlite3.Error as e:
        return jsonify({
            "success": False,
            "error": str(e),
            "sql_attempted": sql,  # Exposing failed SQL (vulnerability)
            "hint": "SQL error occurred - the query may contain syntax issues"
        }), 500
    finally:
        conn.close()


@app.route("/config", methods=["GET"])
def config():
    """
    Sensitive configuration endpoint.
    Requires authentication token but has weak validation.
    """
    auth = request.headers.get("Authorization", "")
    token = request.args.get("token", "")

    effective_token = auth.replace("Bearer ", "") if auth else token

    if not effective_token:
        return jsonify({
            "success": False,
            "error": "Authentication required",
            "hint": "Provide token via Authorization header or ?token= parameter"
        }), 401

    if effective_token != SECRET_TOKEN:
        return jsonify({
            "success": False,
            "error": "Invalid token",
            "message": "The provided token is not valid"
        }), 403

    # Return sensitive data (this should never be exposed in production)
    conn = sqlite3.connect(VICTIM_DB)
    conn.row_factory = sqlite3.Row
    secrets = [dict(r) for r in conn.execute("SELECT * FROM secret_data").fetchall()]
    conn.close()

    return jsonify({
        "success": True,
        "message": "Access granted to sensitive configuration",
        "server_info": {
            "hostname": "demo-victim-server",
            "os": "Linux (simulated)",
            "python_version": "3.11",
            "debug_mode": True,
        },
        "secrets": secrets,
        "warning": "SENSITIVE DATA - This endpoint should not be publicly accessible"
    })


@app.route("/reset", methods=["POST"])
def reset():
    """Reset the victim app state."""
    global login_attempts
    login_attempts = {}
    init_victim_db()
    return jsonify({
        "success": True,
        "message": "Victim app state has been reset",
        "login_attempts_cleared": True,
        "database_reinitialized": True
    })


if __name__ == "__main__":
    init_victim_db()
    print("=" * 50)
    print("  VULNERABLE VICTIM APP (Educational Only)")
    print("  Running on http://localhost:5001")
    print("=" * 50)
    app.run(host="0.0.0.0", port=5001, debug=False)
